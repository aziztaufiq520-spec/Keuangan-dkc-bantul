# Web Keuangan DKC Bantul

Versi awal web sederhana dan responsif.

File utama: index.html
Logo: assets/logo-dkc.png

Cara publikasi paling mudah:
1. Upload folder ini ke GitHub.
2. Hubungkan repository ke Vercel.
3. Klik Deploy.
